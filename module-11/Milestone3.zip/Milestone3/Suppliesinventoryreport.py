#Romany Manriquez
#Outhayvanh Somchaleun
#Kristina Vasquez

import mysql.connector


mydb = mysql.connector.connect(
    host="localhost",
    user="bacchususer",
    password="winewine",
    database="Bacchus"
)


mycursor = mydb.cursor()


query = """
    SELECT 
        name AS supplier_name,
        product,
        delivery_schedule,
        CASE 
            WHEN delivery_schedule = 'Monthly' THEN DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
            WHEN delivery_schedule = 'Weekly' THEN DATE_ADD(CURDATE(), INTERVAL 1 WEEK)
            ELSE CURDATE() 
        END AS expected_delivery_date,
        CASE 
            WHEN delivery_schedule = 'Monthly' AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH) > CURDATE() THEN 'On Time'
            WHEN delivery_schedule = 'Weekly' AND DATE_ADD(CURDATE(), INTERVAL 1 WEEK) > CURDATE() THEN 'On Time'
            ELSE 'Late'
        END AS delivery_status
    FROM Suppliers;
"""


mycursor.execute(query)


columns = [desc[0] for desc in mycursor.description]


print(columns)


results = mycursor.fetchall()


for result in results:
    result = list(result)
    result[3] = str(result[3])  
    print(result)


mycursor.close()
mydb.close()
