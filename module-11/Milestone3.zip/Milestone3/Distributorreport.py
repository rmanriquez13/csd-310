#Romany Manriquez
#Outhayvanh Somchaleun
#Kristina Vasquez

import mysql.connector

# Connect to the database
mydb = mysql.connector.connect(
    host="localhost",
    user="bacchususer",
    password="winewine",
    database="Bacchus"
)


mycursor = mydb.cursor()


query = """
    SELECT 
        w.name AS wine_name,
        d.name AS distributor_name,
        CONCAT('$', FORMAT(SUM(p.quantity), 0)) AS total_sales
    FROM Wines w
    JOIN Production p ON w.wine_id = p.wine_id
    JOIN Distributors d ON w.distributor_id = d.distributor_id
    GROUP BY w.name, d.name
    ORDER BY total_sales DESC;
"""


mycursor.execute(query)


columns = [desc[0] for desc in mycursor.description]


print(columns)


results = mycursor.fetchall()


for result in results:
    print(result)


mycursor.close()
mydb.close()
