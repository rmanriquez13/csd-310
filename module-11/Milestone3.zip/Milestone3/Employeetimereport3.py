#Romany Manriquez
#Outhayvanh Somchaleun
#Kristina Vasquez

import mysql.connector

# Connect to the database
db = mysql.connector.connect(
    host="localhost",
    user="bacchususer",
    password="winewine",
    database="Bacchus"
)
cursor = db.cursor()


query = """
SELECT e.employee_id, e.name, 
       SUM(CASE WHEN p.production_date BETWEEN DATE_SUB(NOW(), INTERVAL 1 YEAR) AND NOW() THEN p.quantity ELSE 0 END) AS total_hours
FROM Employees e
LEFT JOIN Production p ON e.employee_id = p.employee_id
GROUP BY e.employee_id, e.name
ORDER BY e.employee_id
"""


cursor.execute(query)


for (employee_id, name, total_hours) in cursor:
    print(f"Employee ID: {employee_id}, Name: {name}")
    print(f"Total hours for the year: {total_hours} hours\n")


cursor.close()
db.close()
